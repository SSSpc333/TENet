class EnvironmentSettings:
    def __init__(self):
        self.workspace_dir = '/data/Disk_D/pengcheng/project/OSTrack-rgbe'    # Base directory for saving network checkpoints.
        self.tensorboard_dir = '/data/Disk_D/pengcheng/project/OSTrack-rgbe/tensorboard'    # Directory for tensorboard files.
        self.pretrained_networks = '/data/Disk_D/pengcheng/project/OSTrack-rgbe/pretrained_networks'
        self.visevent_dir = '/data/Disk_D/pengcheng/dataset/VisEvent_dataset/train_subset/'
        self.coesot_dir = '/data/Disk_D/pengcheng/dataset/COESOT_dataset/training_subset/'
