"""
Basic OSTrack model.
"""
import torch.nn.functional as F
import math
import os
from typing import List

import torch
import cv2
from torch import nn
import numpy as np
from torch.nn.modules.transformer import _get_clones
from timm.models.vision_transformer import _cfg

from lib.models.layers.head import build_box_head
from lib.models.ostrack.vit import vit_base_patch16_224
from lib.models.ostrack.vit_ce import vit_large_patch16_224_ce, vit_base_patch16_224_ce
from lib.utils.box_ops import box_xyxy_to_cxcywh
from lib.models.ostrack.vit_ce import VisionTransformerCE
from lib.models.ostrack.vit import VisionTransformer
from lib.models.ostrack.utils import token2feature,feature2token
from lib.models.ostrack.poolingEvent import Eventpooling
from lib.models.ostrack.cross_model_attn import Cross_Block


class OSTrack(nn.Module):
    """ This is the base class for OSTrack """

    def __init__(self, backbone, eventpooling, Cross_Block, transformer, box_head, aux_loss=False, head_type="CORNER"):
        """ Initializes the model.
        Parameters:
            transformer: torch module of the transformer architecture.
            aux_loss: True if auxiliary decoding losses (loss at each decoder layer) are to be used.
        """
        super().__init__()
        self.backbone = backbone
        self.event_pooling = eventpooling
        self.cross_modal_attn = Cross_Block
        self.transfomer_block = transformer
        self.box_head = box_head

        self.aux_loss = aux_loss
        self.head_type = head_type
        if head_type == "CORNER" or head_type == "CENTER":
            self.feat_sz_s = int(box_head.feat_sz)
            self.feat_len_s = int(box_head.feat_sz ** 2)
            self.feat_len_s = int(box_head.feat_sz ** 2)

        if self.aux_loss:
            self.box_head = _get_clones(self.box_head, 6)


    def forward(self, template: torch.Tensor,
                search: torch.Tensor,
                ce_template_mask=None,
                ce_keep_rate=None,
                return_last_attn=False,
                ):

        z_rgb = template[:, :3, :, :]
        x_rgb = search[:, :3, :, :]

        z_event = template[:, 3:, :, :]
        x_event = search[:, 3:, :, :]

        x_r, _ = self.backbone(z=z_rgb, x=x_rgb,
                                    ce_template_mask=ce_template_mask,
                                    ce_keep_rate=ce_keep_rate,
                                    return_last_attn=return_last_attn, )

        z_rgb = x_r[:, :x_r.shape[1]-self.feat_len_s, :]
        x_rgb = x_r[:, -self.feat_len_s:, :]
        rgb = token2feature(x_rgb)

        # x_e, _ = self.backbone(z=z_event, x=x_event,
        #                             ce_template_mask=ce_template_mask,
        #                             ce_keep_rate=ce_keep_rate,
        #                             return_last_attn=return_last_attn, )
        #
        # z_event = x_e[:, :x_e.shape[1]-self.feat_len_s, :]
        # x_event = x_e[:, -self.feat_len_s:, :]
        # event = token2feature(x_event)

        # z_rgb = token2feature(z_rgb)
        # x_rgb = token2feature(x_rgb)
        # rgb = x_rgb
        #
        x_event = self.event_pooling(x_event)
        z_event = self.event_pooling(z_event)
        event = x_event

        z_rgb = feature2token(z_rgb)
        z_event = feature2token(z_event)
        x_rgb = feature2token(x_rgb)
        x_event = feature2token(x_event)

        z_rgb = self.cross_modal_attn(z_rgb, z_event, 'rgb')
        z_event = self.cross_modal_attn(z_rgb, z_event, 'event')
        x_rgb = self.cross_modal_attn(x_rgb, x_event, 'rgb')
        x_event = self.cross_modal_attn(x_rgb, x_event, 'event')

        template = z_rgb + z_event
        search = x_rgb + x_event

        x, aux_dict = self.transfomer_block(z=template, x=search)


        # Forward head
        feat_last = x
        if isinstance(x, list):
            feat_last = x[-1]
        # out = self.forward_head(feat_last, None)
        out = self.forward_head(feat_last, rgb, event, None)

        out.update(aux_dict)
        out['backbone_feat'] = x
        return out

    def forward_head(self, cat_feature, x_rgb, x_event, gt_score_map=None):
        """
        cat_feature: output embeddings of the backbone, it can be (HW1+HW2, B, C) or (HW2, B, C)
        """
        #找出搜索区域经过Transformer后的search toekn [32,256,768]
        enc_opt = cat_feature[:, -self.feat_len_s:]  # encoder output for the search region (B, HW, C)
        # unsqueeze(-1) -> [32,256,768,1]
        # permute((0, 3, 2, 1) -> [32,1,768,256]
        opt = (enc_opt.unsqueeze(-1)).permute((0, 3, 2, 1)).contiguous()
        bs, Nq, C, HW = opt.size()
        opt_feat = opt.view(-1, C, self.feat_sz_s, self.feat_sz_s)
        opt_feat = opt_feat + x_rgb + x_event

        if self.head_type == "CORNER":
            # run the corner head
            pred_box, score_map = self.box_head(opt_feat, True)
            outputs_coord = box_xyxy_to_cxcywh(pred_box)
            outputs_coord_new = outputs_coord.view(bs, Nq, 4)
            out = {'pred_boxes': outputs_coord_new,
                   'score_map': score_map,
                   }
            return out

        elif self.head_type == "CENTER":
            # run the center head
            score_map_ctr, bbox, size_map, offset_map = self.box_head(opt_feat, gt_score_map)
            # outputs_coord = box_xyxy_to_cxcywh(bbox)
            outputs_coord = bbox
            outputs_coord_new = outputs_coord.view(bs, Nq, 4)
            out = {'pred_boxes': outputs_coord_new,
                   'score_map': score_map_ctr,
                   'size_map': size_map,
                   'offset_map': offset_map}
            return out
        else:
            raise NotImplementedError


def build_ostrack(cfg, training=True):
    current_dir = os.path.dirname(os.path.abspath(__file__))  # This is your Project Root
    pretrained_path = os.path.join(current_dir, '../../../pretrained_models')
    # 预训练权重的加载
    if cfg.MODEL.PRETRAIN_FILE and ('OSTrack' not in cfg.MODEL.PRETRAIN_FILE) and training:
        pretrained = os.path.join(pretrained_path, cfg.MODEL.PRETRAIN_FILE)
    else:
        pretrained = ''

    if cfg.MODEL.BACKBONE.TYPE == 'vit_base_patch16_224':
        backbone = vit_base_patch16_224(pretrained, drop_path_rate=cfg.TRAIN.DROP_PATH_RATE)
        hidden_dim = backbone.embed_dim
        patch_start_index = 1

    # 使用'vit_base_patch16_224_ce'的backbone
    elif cfg.MODEL.BACKBONE.TYPE == 'vit_base_patch16_224_ce':
        backbone = vit_base_patch16_224_ce(pretrained, drop_path_rate=cfg.TRAIN.DROP_PATH_RATE,
                                           ce_loc=cfg.MODEL.BACKBONE.CE_LOC,
                                           ce_keep_ratio=cfg.MODEL.BACKBONE.CE_KEEP_RATIO,
                                           )
        event_backbone = event_pooling()
        cross_modal_attn = Cross_modal_attn()
        transformer_block = vit_base_embed_224(False)
        hidden_dim = backbone.embed_dim
        patch_start_index = 1

    elif cfg.MODEL.BACKBONE.TYPE == 'vit_large_patch16_224_ce':
        backbone = vit_large_patch16_224_ce(pretrained, drop_path_rate=cfg.TRAIN.DROP_PATH_RATE,
                                            ce_loc=cfg.MODEL.BACKBONE.CE_LOC,
                                            ce_keep_ratio=cfg.MODEL.BACKBONE.CE_KEEP_RATIO,
                                            )

        hidden_dim = backbone.embed_dim
        patch_start_index = 1

    else:
        raise NotImplementedError

    backbone.finetune_track(cfg=cfg, patch_start_index=patch_start_index)

    box_head = build_box_head(cfg, hidden_dim)

    model = OSTrack(
        backbone,
        event_backbone,
        cross_modal_attn,
        transformer_block,
        box_head,
        aux_loss=False,
        head_type=cfg.MODEL.HEAD.TYPE,
    )

    if 'OSTrack' in cfg.MODEL.PRETRAIN_FILE and training:
        checkpoint = torch.load(cfg.MODEL.PRETRAIN_FILE, map_location="cpu")
        missing_keys, unexpected_keys = model.load_state_dict(checkpoint["net"], strict=False)
        print('Load pretrained model from: ' + cfg.MODEL.PRETRAIN_FILE)

    return model



def _create_vision_transformerCE(pretrained=False, **kwargs):
    model = VisionTransformerCE(**kwargs)
    if pretrained:
        if 'npz' in pretrained:
            model.load_pretrained(pretrained, prefix='')
        else:
            checkpoint = torch.load(pretrained, map_location="cpu")
            # 映射到cpu上，在cpu上加载模型
            missing_keys, unexpected_keys = model.load_state_dict(checkpoint["model"], strict=False)
            # 加载model中的参数
            print('Load pretrained model from: ' + pretrained)
    return model


def event_pooling():
    model_kwargs = dict(
        embed_dims=[64, 256, 768], inplanes=3, downsamping=4, ca_num_heads=4, kernel=[3, 5, 7, 9], padding=[1, 2, 3, 4], stage=2
    )

    model = Eventpooling(**model_kwargs)
    return model


def _create_vision_transformer(pretrained=False, **kwargs):
    model = VisionTransformer(**kwargs)
    return model


def vit_base_embed_224(pretrained=False, **kwargs):
    """
    ViT-Base model (ViT-B/16) from original paper (https://arxiv.org/abs/2010.11929).
    """
    model_kwargs = dict(
        patch_size=16, embed_dim=768, depth=4, num_heads=16, **kwargs)
    model = _create_vision_transformer(pretrained=pretrained, **model_kwargs)
    return model

def Cross_modal_attn():
    model = Cross_Block(dim=768, num_heads=16)
    return model
