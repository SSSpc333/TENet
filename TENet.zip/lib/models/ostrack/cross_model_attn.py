import torch
import os
import torch.nn as nn
from timm.models.layers import DropPath, Mlp
from lib.models.ostrack.utils import token2feature,feature2token


# class Attention(nn.Module):
#     def __init__(self, dim, num_heads=8, qkv_bias=False, attn_drop=0., proj_drop=0.):
#         super().__init__()
#         self.num_heads = num_heads
#         head_dim = dim // num_heads
#         self.scale = head_dim ** -0.5
#
#         self.kv1 = nn.Linear(dim, dim * 2, bias=qkv_bias)
#         self.kv2 = nn.Linear(dim, dim * 2, bias=qkv_bias)
#         self.attn_drop = nn.Dropout(attn_drop)
#         self.proj = nn.Linear(dim, dim)
#         self.proj_drop = nn.Dropout(proj_drop)
#
#     def forward(self, rgb, event, modal):
#         B, N, C = rgb.shape
#         if modal == 'rgb':
#             kv = self.kv2(rgb).reshape(B, N, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
#             q = event.reshape(B, N, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)
#             k, v = kv[0], kv[1]
#         else:
#             kv = self.kv1(event).reshape(B, N, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
#             q = rgb.reshape(B, N, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)
#             k, v = kv[0], kv[1]
#
#         attn = (q @ k.transpose(-2, -1)) * self.scale
#         attn = attn.softmax(dim=-1)
#         attn = self.attn_drop(attn)
#
#         x = (attn @ v).transpose(1, 2).reshape(B, N, C)
#         x = self.proj(x)
#         x = self.proj_drop(x)
#
#         return x
#         # return x,attn


class Attention(nn.Module):
    def __init__(self, dim, num_heads=8, qkv_bias=False, attn_drop=0., proj_drop=0.):
        super().__init__()
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = head_dim ** -0.5

        self.kv1 = nn.Linear(dim, dim * 2, bias=qkv_bias)
        self.kv2 = nn.Linear(dim, dim * 2, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)
        self.downsample = nn.MaxPool2d(kernel_size=2, stride=2, padding=0)

    def forward(self, rgb, event, modal):
        B, N_old, C = rgb.shape
        H = W = int(N_old ** 0.5)
        if modal == 'rgb':
            rgb_down = rgb.view(B, H, W, C).permute(0, 3, 1, 2).contiguous()
            rgb_down = feature2token(self.downsample(rgb_down))
            B, N_new, C = rgb_down.shape
            kv = self.kv2(rgb_down).reshape(B, N_new, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
            q = event.reshape(B, N_old, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)
            k, v = kv[0], kv[1]
        else:
            event_down = event.view(B, H, W, C).permute(0, 3, 1, 2).contiguous()
            event_down = feature2token(self.downsample(event_down))
            B, N_new, C = event_down.shape
            kv = self.kv1(event_down).reshape(B, N_new, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
            q = rgb.reshape(B, N_old, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)
            k, v = kv[0], kv[1]

        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        x = (attn @ v).transpose(1, 2).reshape(B, N_old, C)
        x = self.proj(x)
        x = self.proj_drop(x)

        return x
        # return x,attn


class Cross_Block(nn.Module):

    def __init__(self, dim, num_heads, mlp_ratio=4., qkv_bias=False, drop=0., attn_drop=0.,
                 drop_path=0., act_layer=nn.GELU, norm_layer=nn.LayerNorm):
        super().__init__()
        self.norm1 = norm_layer(dim)
        self.attn = Attention(dim, num_heads=num_heads, qkv_bias=qkv_bias, attn_drop=attn_drop, proj_drop=drop)
        # NOTE: drop path for stochastic depth, we shall see if this is better than dropout here
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.norm2 = norm_layer(dim)
        self.norm3 = norm_layer(dim)
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)

    def forward(self, rgb, event, modal='rgb'):
        if modal == 'rgb':
            x = rgb
        else:
            x = event
        rgb = self.norm1(rgb)
        event = self.norm2(event)
        # x, attn = self.attn(rgb, event, modal)
        # x = x + self.drop_path(x)
        x = x + self.drop_path(self.attn(rgb, event, modal))
        x = x + self.mlp(self.norm3(x))

        return x

# if __name__ == '__main__':
#     os.environ['CUDA_VISIBLE_DEVICES'] = '3'
#     model = Cross_Block(dim=768, num_heads=16)
#     model = model.cuda()
#     rgb = torch.FloatTensor(32, 256, 768).cuda()
#     event = torch.FloatTensor(32, 256, 768).cuda()
#     x_rgb = model(rgb, event, 'rgb')
#     x_event = model(rgb, event, 'event')
#     print('Ending.')