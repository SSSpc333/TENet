
# single deep_rgbe
CUDA_VISIBLE_DEVICES=3 python tracking/train.py --script ostrack --config deep_rgbe --save_dir ./output --mode single

# single coesot
#CUDA_VISIBLE_DEVICES=3 python tracking/train.py --script ostrack --config coesot --save_dir ./output --mode single
