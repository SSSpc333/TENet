# deep_rgbe
CUDA_VISIBLE_DEVICES=0,1,2,3 python ./RGBE_workspace/rgbe_mgpus2.py --script_name ostrack --yaml_name deep_rgbe --threads 4 --num_gpus 4
# coesot
#CUDA_VISIBLE_DEVICES=0,1,2,3 python ./RGBE_workspace/rgbe_coesot.py --script_name ostrack --yaml_name coesot --threads 4 --num_gpus 4
