
## Training
Download [pre-trained](https://drive.google.com/file/d/13J_EiA_ef5_h07Y8CtkSfwLLRhxgy_W4/view?usp=drive_link) and put it under `$PROJECT_ROOT$/pretrained_models`.

