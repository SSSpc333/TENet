# import torch.nn as nn
#
# class Eventpooling(nn.Module):
#     def __init__(self, embed_dims=[64, 128, 256], inplanes=3, downsamping=4, **kwargs):
#         super().__init__()
#
#         self.conv0 = nn.Conv2d(in_channels=inplanes, out_channels=embed_dims[0], kernel_size=1, stride=1, padding=0)
#         self.conv1 = nn.Conv2d(in_channels=embed_dims[0], out_channels=embed_dims[1],kernel_size=1, stride=1, padding=0)
#         self.conv2 = nn.Conv2d(in_channels=embed_dims[1], out_channels=embed_dims[2],kernel_size=1, stride=1, padding=0)
#         self.max_pool0 = nn.MaxPool2d(kernel_size=downsamping, stride=downsamping)
#         self.avg_pool1 = nn.AvgPool2d(kernel_size=int(downsamping/2), stride=int(downsamping/2))
#         self.max_pool1 = nn.MaxPool2d(kernel_size=int(downsamping/2), stride=int(downsamping/2))
#         self.max_pool2 = nn.MaxPool2d(kernel_size=int(downsamping/2), stride=int(downsamping/2))
#
#         self.relu = nn.ReLU()
#
#     def forward(self, x):
#         x = self.relu(self.conv0(x))
#         x = self.max_pool0(x)
#
#         x = self.relu(self.conv1(x))
#         x_avg = self.avg_pool1(x)
#         x_max = self.max_pool1(x)
#         x = x_avg + x_max
#
#         x = self.relu(self.conv2(x))
#         x = self.max_pool2(x)
#
#         return x

import torch
import torch.nn as nn

class Eventpooling(nn.Module):
    def __init__(self, embed_dims=[64, 128, 256], inplanes=3, downsamping=4, ca_num_heads=4, kernel=[3, 5, 7, 9], padding=[1, 2, 3, 4], stage=2, **kwargs):
        super().__init__()
        self.ca_num_heads = ca_num_heads
        self.kernel = kernel
        self.padding = padding
        self.embed_dims = embed_dims
        self.stage = stage
        self.conv0_0 = nn.Conv2d(in_channels=inplanes, out_channels=embed_dims[0], kernel_size=1, stride=1, padding=0)
        self.conv0_1 = nn.Conv2d(in_channels=embed_dims[0], out_channels=embed_dims[0], kernel_size=1, stride=1, padding=0)


        self.max_pool0_0 = nn.MaxPool2d(kernel_size=int(downsamping/2), stride=int(downsamping/2))
        self.avg_pool0_0 = nn.AvgPool2d(kernel_size=int(downsamping/2), stride=int(downsamping/2))

        for i in range(self.ca_num_heads):
            max_pool = nn.MaxPool2d(kernel_size=self.kernel[i], stride=1, padding=self.padding[i])
            setattr(self, f"max_pool_{i}", max_pool)

        for i in range(self.stage):
            conv0 = nn.Conv2d(in_channels=embed_dims[i], out_channels=embed_dims[i+1], kernel_size=2, stride=2, padding=0)
            setattr(self, f"conv_{i+1}_0", conv0)
            conv1 = nn.Conv2d(in_channels=embed_dims[i+1], out_channels=embed_dims[i+1], kernel_size=1, stride=1,padding=0)
            setattr(self, f"conv_{i+1}_1", conv1)
            conv2 = nn.Conv2d(in_channels=embed_dims[i+1], out_channels=embed_dims[i+1], kernel_size=1, stride=1, padding=0)
            setattr(self, f"conv_{i+1}_2", conv2)

        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):

        # stage 1
        x = self.relu(self.conv0_0(x))
        x = self.max_pool0_0(x)
        x = self.relu(self.conv0_1(x))
        x_avg = self.avg_pool0_0(x)
        x_max = self.max_pool0_0(x)
        x = x_max + x_avg

        for i in range(self.stage):
            conv0 = getattr(self, f"conv_{i+1}_0")
            x = self.relu(conv0(x))
            x_ori = x
            conv1 = getattr(self, f"conv_{i+1}_1")
            x = self.relu(conv1(x))
            channel_splits = torch.split(x, int(self.embed_dims[i+1]/4), dim=1)
            for s in range(self.ca_num_heads):
                if s == 0 or s == 1:
                    x_s = channel_splits[s]
                else:
                    x_s = x_s + channel_splits[s]
                max_pool = getattr(self, f"max_pool_{s}")
                x_s = max_pool(x_s)
                if s == 0:
                    x_out = x_s
                else:
                    x_out = torch.cat([x_out, x_s], dim=1)
            conv2 = getattr(self, f"conv_{i+1}_2")
            x_out = conv2(x_out)
            x = x_out + x_ori
            x = self.relu(x)

        return x














